import React, { useEffect, useState } from 'react'
import useDymanicForm from '../../hooks/useDynamicForm'
import { useDispatch, useSelector } from 'react-redux'
import { AddOrder, AddUser, DeleteUser, GetUser, GetUserOrder } from '../../redux/Actions/AdminAction'
import { invalidate } from '../../redux/slices/AdminSlices'
import { toast } from 'react-toastify'

const Dashboard = () => {

    const dispatch = useDispatch()
    const handleSubmit = e => {
        dispatch(AddUser(state))
    }


    const config = [
        { fieldName: "fname", type: "text" },
        { fieldName: "address", type: "text" },
        { fieldName: "mobile", type: "number" },
        { fieldName: "Add New Customer", type: "submit", onClick: handleSubmit },
    ]
    const [selectedUser, setselectedUser] = useState()

    const handleOrderSubmit = e => {
        dispatch(AddOrder({ ...orstate, userId: selectedUser.id }))
    }


    const [ui, state, pre] = useDymanicForm(config)
    const [orui, orstate, orpre] = useDymanicForm(
        [
            { fieldName: "Jars", type: "number" },
            { fieldName: "date", type: "date" },
            { fieldName: "Add New Order", type: "submit", onClick: handleOrderSubmit }
        ]
    )


    const { users, Adduser, userDelete, userOrders } = useSelector(state => state.admin)


    useEffect(() => {
        if (AddUser) {
            dispatch(GetUser())
            dispatch(invalidate())
            toast.success("User Add Successfully")
        }
    }, [Adduser])


    useEffect(() => {
        if (userDelete) {
            dispatch(GetUser())
            dispatch(invalidate())
            toast.error("User Delete Successfully")
        }
    }, [userDelete])

    useEffect(() => {
        dispatch(GetUser())

    }, [])


    return <>


        <div className="text-right mt-2 me-11">

            <button className="btn btn-primary mt-7" onClick={() => window.my_modal_3.showModal()}>Add Customer</button>
        </div>


        <dialog id="my_modal_3" className="modal">
            <form method="dialog" className="modal-box">
                <button className="btn btn-sm btn-circle btn-ghost absolute right-2 top-2">✕</button>
                <h3 className="font-bold text-lg">Add New Customer!</h3>
                <p className="py-4">{ui}</p>
            </form>
        </dialog>



        <div className="overflow-x-auto">
            <table className="table">
                {/* head */}
                <thead>
                    <tr>
                        <th>No.</th>
                        <th>Name</th>
                        <th>Address</th>
                        <th>Mobile</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>

                    {
                        users && users.map(item => <tr key={item.id}>

                            <td>{item.id}</td>
                            <td>{item.fname}</td>
                            <td>{item.address}</td>
                            <td>{item.mobile}</td>
                            <td className='flex gap-3'>
                                <button onClick={() => { window.my_modal_4.showModal(), setselectedUser(item) }} type="button" class="btn btn-primary"><sup className='text-lg'>+</sup>Order</button>
                                <button onClick={() => { window.my_modal_5.showModal(), dispatch(GetUserOrder(item.id)) }} className="btn btn-primary">History</button>
                                <button onClick={e => dispatch(DeleteUser(item.id))} type="button" class="btn btn-error">Delete</button>
                            </td>

                        </tr>
                        )
                    }



                </tbody>

            </table>
        </div>




        {/* Order Modal */}


        <dialog id="my_modal_4" className="modal">
            <form method="dialog" className="modal-box">
                <button className="btn btn-sm btn-circle btn-ghost absolute right-2 top-2">✕</button>
                <h3 className="font-bold text-lg">Hello Add Order !</h3>
                <p className="py-4">
                    {orui}
                </p>
            </form>
        </dialog>





        <dialog id="my_modal_5" className="modal">
            <form method="dialog" className="modal-box">
                <button className="btn btn-sm btn-circle btn-ghost absolute right-2 top-2">✕</button>
                <h3 className="font-bold text-lg">Hello!</h3>
                <p className="py-4">

                    <h1>Jars : {userOrders && userOrders[0].Jars}</h1>
                    <h1>date :  {userOrders && userOrders[0].date}</h1>

                </p>
            </form>
        </dialog>





    </>
}

export default Dashboard